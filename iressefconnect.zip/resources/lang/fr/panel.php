<?php

return [
    'site_title' => 'IressefConnect',
];
