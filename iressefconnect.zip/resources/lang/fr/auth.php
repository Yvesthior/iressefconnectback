<?php

return [
    'failed'   => 'Ces identifiants ne sont pas reconnus.',
    'password' => 'Mot de passe erroné.',
    'throttle' => 'Top d\'echec de tentatives de connexion. Veuillez réessayer dans :seconds secondes.',
];
