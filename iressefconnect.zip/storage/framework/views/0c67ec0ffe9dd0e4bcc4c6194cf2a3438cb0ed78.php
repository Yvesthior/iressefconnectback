<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.analysi.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.analysis.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="naissance"><?php echo e(trans('cruds.analysi.fields.naissance')); ?></label>
                <input class="form-control <?php echo e($errors->has('naissance') ? 'is-invalid' : ''); ?>" type="text" name="naissance" id="naissance" value="<?php echo e(old('naissance', '')); ?>">
                <?php if($errors->has('naissance')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('naissance')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.naissance_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="heure_prelev"><?php echo e(trans('cruds.analysi.fields.heure_prelev')); ?></label>
                <input class="form-control <?php echo e($errors->has('heure_prelev') ? 'is-invalid' : ''); ?>" type="text" name="heure_prelev" id="heure_prelev" value="<?php echo e(old('heure_prelev', '')); ?>">
                <?php if($errors->has('heure_prelev')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('heure_prelev')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.heure_prelev_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="date_prelev"><?php echo e(trans('cruds.analysi.fields.date_prelev')); ?></label>
                <input class="form-control <?php echo e($errors->has('date_prelev') ? 'is-invalid' : ''); ?>" type="text" name="date_prelev" id="date_prelev" value="<?php echo e(old('date_prelev', '')); ?>" required>
                <?php if($errors->has('date_prelev')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('date_prelev')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.date_prelev_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="identification"><?php echo e(trans('cruds.analysi.fields.identification')); ?></label>
                <input class="form-control <?php echo e($errors->has('identification') ? 'is-invalid' : ''); ?>" type="text" name="identification" id="identification" value="<?php echo e(old('identification', '')); ?>" required>
                <?php if($errors->has('identification')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('identification')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.identification_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="prenom"><?php echo e(trans('cruds.analysi.fields.prenom')); ?></label>
                <input class="form-control <?php echo e($errors->has('prenom') ? 'is-invalid' : ''); ?>" type="text" name="prenom" id="prenom" value="<?php echo e(old('prenom', '')); ?>" required>
                <?php if($errors->has('prenom')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('prenom')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.prenom_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="nom"><?php echo e(trans('cruds.analysi.fields.nom')); ?></label>
                <input class="form-control <?php echo e($errors->has('nom') ? 'is-invalid' : ''); ?>" type="text" name="nom" id="nom" value="<?php echo e(old('nom', '')); ?>" required>
                <?php if($errors->has('nom')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nom')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.nom_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="technique"><?php echo e(trans('cruds.analysi.fields.technique')); ?></label>
                <input class="form-control <?php echo e($errors->has('technique') ? 'is-invalid' : ''); ?>" type="text" name="technique" id="technique" value="<?php echo e(old('technique', '')); ?>" required>
                <?php if($errors->has('technique')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('technique')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.technique_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="ct"><?php echo e(trans('cruds.analysi.fields.ct')); ?></label>
                <input class="form-control <?php echo e($errors->has('ct') ? 'is-invalid' : ''); ?>" type="text" name="ct" id="ct" value="<?php echo e(old('ct', '')); ?>" required>
                <?php if($errors->has('ct')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('ct')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.ct_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="resultat"><?php echo e(trans('cruds.analysi.fields.resultat')); ?></label>
                <input class="form-control <?php echo e($errors->has('resultat') ? 'is-invalid' : ''); ?>" type="text" name="resultat" id="resultat" value="<?php echo e(old('resultat', '')); ?>" required>
                <?php if($errors->has('resultat')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('resultat')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.resultat_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="conclusion"><?php echo e(trans('cruds.analysi.fields.conclusion')); ?></label>
                <input class="form-control <?php echo e($errors->has('conclusion') ? 'is-invalid' : ''); ?>" type="text" name="conclusion" id="conclusion" value="<?php echo e(old('conclusion', '')); ?>" required>
                <?php if($errors->has('conclusion')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('conclusion')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.conclusion_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="origine_prelev"><?php echo e(trans('cruds.analysi.fields.origine_prelev')); ?></label>
                <input class="form-control <?php echo e($errors->has('origine_prelev') ? 'is-invalid' : ''); ?>" type="text" name="origine_prelev" id="origine_prelev" value="<?php echo e(old('origine_prelev', '')); ?>" required>
                <?php if($errors->has('origine_prelev')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('origine_prelev')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.origine_prelev_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="date_rendu"><?php echo e(trans('cruds.analysi.fields.date_rendu')); ?></label>
                <input class="form-control <?php echo e($errors->has('date_rendu') ? 'is-invalid' : ''); ?>" type="text" name="date_rendu" id="date_rendu" value="<?php echo e(old('date_rendu', '')); ?>" required>
                <?php if($errors->has('date_rendu')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('date_rendu')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.date_rendu_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="type_cas"><?php echo e(trans('cruds.analysi.fields.type_cas')); ?></label>
                <input class="form-control <?php echo e($errors->has('type_cas') ? 'is-invalid' : ''); ?>" type="text" name="type_cas" id="type_cas" value="<?php echo e(old('type_cas', '')); ?>" required>
                <?php if($errors->has('type_cas')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('type_cas')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.type_cas_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="age"><?php echo e(trans('cruds.analysi.fields.age')); ?></label>
                <input class="form-control <?php echo e($errors->has('age') ? 'is-invalid' : ''); ?>" type="text" name="age" id="age" value="<?php echo e(old('age', '')); ?>" required>
                <?php if($errors->has('age')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('age')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.age_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="sexe"><?php echo e(trans('cruds.analysi.fields.sexe')); ?></label>
                <input class="form-control <?php echo e($errors->has('sexe') ? 'is-invalid' : ''); ?>" type="text" name="sexe" id="sexe" value="<?php echo e(old('sexe', '')); ?>" required>
                <?php if($errors->has('sexe')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('sexe')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.sexe_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="email"><?php echo e(trans('cruds.analysi.fields.email')); ?></label>
                <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="text" name="email" id="email" value="<?php echo e(old('email', '')); ?>" required>
                <?php if($errors->has('email')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('email')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.email_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="whatsapp"><?php echo e(trans('cruds.analysi.fields.whatsapp')); ?></label>
                <input class="form-control <?php echo e($errors->has('whatsapp') ? 'is-invalid' : ''); ?>" type="text" name="whatsapp" id="whatsapp" value="<?php echo e(old('whatsapp', '')); ?>" required>
                <?php if($errors->has('whatsapp')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('whatsapp')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.whatsapp_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="code_interne"><?php echo e(trans('cruds.analysi.fields.code_interne')); ?></label>
                <input class="form-control <?php echo e($errors->has('code_interne') ? 'is-invalid' : ''); ?>" type="text" name="code_interne" id="code_interne" value="<?php echo e(old('code_interne', '')); ?>" required>
                <?php if($errors->has('code_interne')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('code_interne')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.code_interne_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="adresse"><?php echo e(trans('cruds.analysi.fields.adresse')); ?></label>
                <input class="form-control <?php echo e($errors->has('adresse') ? 'is-invalid' : ''); ?>" type="text" name="adresse" id="adresse" value="<?php echo e(old('adresse', '')); ?>">
                <?php if($errors->has('adresse')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('adresse')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.adresse_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="telephone"><?php echo e(trans('cruds.analysi.fields.telephone')); ?></label>
                <input class="form-control <?php echo e($errors->has('telephone') ? 'is-invalid' : ''); ?>" type="text" name="telephone" id="telephone" value="<?php echo e(old('telephone', '')); ?>" required>
                <?php if($errors->has('telephone')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('telephone')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.analysi.fields.telephone_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\iressefconnect\resources\views/admin/analysis/create.blade.php ENDPATH**/ ?>