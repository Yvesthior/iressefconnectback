<?php $__env->startSection('content'); ?>

<div class='row'>
    <div class='col-md-12'>
        <div class="card panel-default">
            <div class="card-header">
                <?php echo app('translator')->get('global.app_csvImport'); ?>
            </div>

            <div class="card-body table-responsive">
                <form class="form-horizontal" method="POST" action="<?php echo e(route($routeName)); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="filename" value="<?php echo e($filename); ?>" />
                    <input type="hidden" name="hasHeader" value="<?php echo e($hasHeader); ?>" />
                    <input type="hidden" name="modelName" value="<?php echo e($modelName); ?>" />
                    <input type="hidden" name="redirect" value="<?php echo e($redirect); ?>" />

                    <table class="table">
                        <?php if(isset($headers)): ?>
                            <tr>
                                <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($field); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endif; ?>
                        <?php if($lines): ?>
                            <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php $__currentLoopData = $line; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($field); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <tr>
                            <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <select name="fields[<?php echo e($key); ?>]">
                                        <option value=''>Please select</option>
                                        <?php $__currentLoopData = $fillables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $fillable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($fillable); ?>" <?php echo e(strtolower($header) === strtolower($fillable) ? 'selected' : ''); ?>><?php echo e($fillable); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </table>

                    <button type="submit" class="btn btn-primary">
                        <?php echo app('translator')->get('global.app_import_data'); ?>
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\iressefconnect\resources\views/csvImport/parseInput.blade.php ENDPATH**/ ?>