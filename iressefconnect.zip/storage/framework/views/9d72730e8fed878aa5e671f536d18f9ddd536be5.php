<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.analysi.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.analysis.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.naissance')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->naissance); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.heure_prelev')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->heure_prelev); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.date_prelev')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->date_prelev); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.identification')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->identification); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.prenom')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->prenom); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.nom')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->nom); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.technique')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->technique); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.ct')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->ct); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.resultat')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->resultat); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.conclusion')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->conclusion); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.origine_prelev')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->origine_prelev); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.date_rendu')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->date_rendu); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.type_cas')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->type_cas); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.age')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->age); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.sexe')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->sexe); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.email')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->email); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.whatsapp')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->whatsapp); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.code_interne')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->code_interne); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.adresse')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->adresse); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.analysi.fields.telephone')); ?>

                        </th>
                        <td>
                            <?php echo e($analysi->telephone); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.analysis.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\iressefconnect\resources\views/admin/analysis/show.blade.php ENDPATH**/ ?>